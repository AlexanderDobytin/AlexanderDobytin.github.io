'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Popup = function () {
    function Popup(type) {
        var _this = this;

        _classCallCheck(this, Popup);

        if (type) {
            var item = $('.b-popup[data-type="' + type + '"]');
            if (item != undefined) {
                this.item = item;
                this.action('open');

                $(item).on('click', function (event) {
                    console.log(event.target == event.currentTarget);
                    if (event.target == event.currentTarget) {
                        _this.action('close');
                    }
                });
            }
        } else {
            return false;
        }
    }

    _createClass(Popup, [{
        key: 'action',
        value: function action(type) {
            type == 'open' ? this.open() : this.close();
        }
    }, {
        key: 'open',
        value: function open() {

            $(this.item).addClass('b-popup--active');
        }
    }, {
        key: 'close',
        value: function close() {

            $(this.item).removeClass('b-popup--active');
        }
    }]);

    return Popup;
}();

var Button = function () {
    function Button(item) {
        var _this2 = this;

        _classCallCheck(this, Button);

        this.item = item;
        $(item).on('click', function (item) {
            _this2.onClick();
        });
    }

    _createClass(Button, [{
        key: 'onClick',
        value: function onClick() {
            var type = $(this.item).data('popup');
            new Popup(type);
        }
    }]);

    return Button;
}();

var Block = function () {
    function Block(item) {
        var _this3 = this;

        _classCallCheck(this, Block);

        this.item = item;
        this.startWidth = $(item).width();
        this.startHeight = $(item).height();
        $('.b-popup-header__button').on('click', function (event, item) {
            _this3.click(event.target);
        });
    }

    _createClass(Block, [{
        key: 'click',
        value: function click(item) {

            var type = $(item).data('type');
            console.log(type);
            switch (type) {
                case 1:
                    this.x2();
                    break;
                case 2:
                    this.divide();
                    break;
                case 3:
                    this.toStart();
                    break;
            }
        }
    }, {
        key: 'x2',
        value: function x2() {
            $(this.item).animate({ 'width': this.startWidth * 2, 'height': this.startHeight * 2 }, 1500);
        }
    }, {
        key: 'divide',
        value: function divide() {
            $(this.item).animate({ 'width': this.startWidth / 2, 'height': this.startHeight / 2 }, 1500);
        }
    }, {
        key: 'toStart',
        value: function toStart() {
            $(this.item).animate({ 'width': this.startWidth, 'height': this.startHeight }, 1500);
        }
    }]);

    return Block;
}();

$(document).ready(function () {
    new Block($('#block'));
    $('.b-btn').each(function () {
        new Button(this);
    });
});